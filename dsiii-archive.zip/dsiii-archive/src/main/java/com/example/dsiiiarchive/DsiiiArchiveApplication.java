package com.example.dsiiiarchive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsiiiArchiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsiiiArchiveApplication.class, args);
	}

}
