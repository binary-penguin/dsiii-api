package com.example.dsiiiarchive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsiiiArchiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
